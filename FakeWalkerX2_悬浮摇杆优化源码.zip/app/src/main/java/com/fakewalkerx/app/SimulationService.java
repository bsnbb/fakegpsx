package com.fakewalkerx.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.location.*;
import android.os.*;
import android.provider.Settings;
import java.util.*;

/** Foreground owner for mock-location updates; keeps simulation independent from Activity lifetime. */
public class SimulationService extends Service {
    public static final String ACTION_START="com.fakewalkerx.app.SIM_START";
    public static final String ACTION_TOGGLE="com.fakewalkerx.app.SIM_TOGGLE";
    public static final String ACTION_STOP="com.fakewalkerx.app.SIM_STOP";
    public static final String ACTION_POSITION="com.fakewalkerx.app.SIM_POSITION";
    public static final String ACTION_FINISHED="com.fakewalkerx.app.SIM_FINISHED";
    public static final String ACTION_ERROR="com.fakewalkerx.app.SIM_ERROR";
    private LocationManager lm; private Handler handler; private boolean running=false, paused=false;
    private double lat,lon,speed=1.3,joyX,joyY,stepFraction=0; private int routeIndex=1,cadence=110,strideCm=65,intervalMs=500; private long steps=0,lastTickMs=0;
    private static class RoutePoint { final double latitude, longitude; RoutePoint(double lat,double lon){latitude=lat;longitude=lon;} }
    private final ArrayList<RoutePoint> route=new ArrayList<>();
    private BroadcastReceiver joystickReceiver;
    private final Runnable ticker=new Runnable(){@Override public void run(){if(!running||paused)return;long now=SystemClock.elapsedRealtime();double dt=lastTickMs==0?intervalMs/1000.0:Math.min(2.0,(now-lastTickMs)/1000.0);lastTickMs=now;try{boolean moving=false;if(route.size()>1){advanceRoute(dt);moving=running;}else if(Math.abs(joyX)>.02||Math.abs(joyY)>.02){double magnitude=Math.min(1.0,Math.hypot(joyX,joyY));double metersPerTick=speed*magnitude*dt;lat+=(-joyY*metersPerTick)/111320.0;lon+=(joyX*metersPerTick)/Math.max(1000,111320*Math.cos(Math.toRadians(lat)));moving=true;}if(moving){stepFraction+=cadence*dt/60.0;long whole=(long)stepFraction;if(whole>0){steps+=whole;stepFraction-=whole;}}publish();sendPosition();}catch(Exception e){android.util.Log.e("FakeWalkerX","Location tick failed",e);}if(running&&!paused)handler.postDelayed(this,intervalMs);}};
    @Override public void onCreate(){super.onCreate();lm=(LocationManager)getSystemService(LOCATION_SERVICE);handler=new Handler(Looper.getMainLooper());createChannel();startForeground(41,notification("等待启动模拟"));joystickReceiver=new BroadcastReceiver(){@Override public void onReceive(Context c,Intent i){joyX=i.getFloatExtra("x",0);joyY=i.getFloatExtra("y",0);}};IntentFilter f=new IntentFilter(MainActivity.ACTION_JOYSTICK);if(Build.VERSION.SDK_INT>=33)registerReceiver(joystickReceiver,f,Context.RECEIVER_NOT_EXPORTED);else registerReceiver(joystickReceiver,f);}
    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel("fwx_simulation","FakeWalker X 定位模拟",NotificationManager.IMPORTANCE_LOW);((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);}}
    private Notification notification(String text){if(Build.VERSION.SDK_INT>=26)return new Notification.Builder(this,"fwx_simulation").setContentTitle("FakeWalker X 定位模拟").setContentText(text).setSmallIcon(android.R.drawable.ic_media_play).setOngoing(true).build();return new Notification.Builder(this).setContentTitle("FakeWalker X 定位模拟").setContentText(text).setSmallIcon(android.R.drawable.ic_media_play).setOngoing(true).build();}
    @Override public int onStartCommand(Intent i,int flags,int startId){if(i==null)return START_STICKY;String action=i.getAction();if(ACTION_START.equals(action)){lat=i.getDoubleExtra("lat",35.6812);lon=i.getDoubleExtra("lon",139.7671);speed=Math.max(.3,i.getDoubleExtra("speed",1.3));cadence=Math.max(1,Math.min(240,i.getIntExtra("cadence",110)));strideCm=Math.max(20,Math.min(120,i.getIntExtra("stride",65)));intervalMs=Math.max(250,Math.min(2000,getSharedPreferences("settings",MODE_PRIVATE).getInt("interval",500)));steps=0;stepFraction=0;lastTickMs=0;route.clear();double[] lats=i.getDoubleArrayExtra("route_lats"),lons=i.getDoubleArrayExtra("route_lons");if(lats!=null&&lons!=null)for(int n=0;n<Math.min(lats.length,lons.length);n++)route.add(new RoutePoint(lats[n],lons[n]));routeIndex=1;try{prepareProvider();running=true;paused=false;handler.removeCallbacks(ticker);handler.post(ticker);publish();sendPosition();}catch(Exception e){Intent error=new Intent(ACTION_ERROR);error.setPackage(getPackageName());error.putExtra("message",friendlyError(e));sendBroadcast(error);android.util.Log.e("FakeWalkerX","Unable to start mock location",e);stopSimulation();stopSelf();}}else if(ACTION_TOGGLE.equals(action)){paused=!paused;if(!paused&&running){lastTickMs=0;handler.post(ticker);}else handler.removeCallbacks(ticker); }else if(ACTION_STOP.equals(action)){stopSimulation();stopSelf();}return START_STICKY;}
    private String friendlyError(Exception e){
        if(e instanceof SecurityException) return "模拟定位启动失败：请在开发者选项中将 FakeWalker X 设为模拟位置信息应用，并确认已授予精确位置权限。";
        String detail=e.getMessage();
        return "模拟定位启动失败："+(detail==null||detail.trim().isEmpty()?"请检查系统定位权限和模拟位置设置。":detail);
    }
    private void prepareProvider(){if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)throw new SecurityException("缺少精确定位权限");try{lm.removeTestProvider(LocationManager.GPS_PROVIDER);}catch(Exception ignored){}if(Build.VERSION.SDK_INT>=31){android.location.provider.ProviderProperties p=new android.location.provider.ProviderProperties.Builder().setAccuracy(android.location.provider.ProviderProperties.ACCURACY_FINE).setPowerUsage(android.location.provider.ProviderProperties.POWER_USAGE_HIGH).build();lm.addTestProvider(LocationManager.GPS_PROVIDER,p);}else{lm.addTestProvider(LocationManager.GPS_PROVIDER,false,true,false,false,true,true,true,Criteria.POWER_HIGH,Criteria.ACCURACY_FINE);}lm.setTestProviderEnabled(LocationManager.GPS_PROVIDER,true);}
    private void publish(){Location l=new Location(LocationManager.GPS_PROVIDER);l.setLatitude(lat);l.setLongitude(lon);l.setAccuracy(3);l.setSpeed((float)speed);l.setTime(System.currentTimeMillis());if(Build.VERSION.SDK_INT>=17)l.setElapsedRealtimeNanos(SystemClock.elapsedRealtimeNanos());lm.setTestProviderLocation(LocationManager.GPS_PROVIDER,l);}
    private void advanceRoute(double dt){if(routeIndex>=route.size()){Intent done=new Intent(ACTION_FINISHED);done.setPackage(getPackageName());sendBroadcast(done);stopSimulation();stopSelf();return;}RoutePoint target=route.get(routeIndex);float[] d=new float[1];Location.distanceBetween(lat,lon,target.latitude,target.longitude,d);double step=Math.max(.2,speed*dt);if(d[0]<=step){lat=target.latitude;lon=target.longitude;routeIndex++;}else{double r=step/d[0];lat+=(target.latitude-lat)*r;lon+=(target.longitude-lon)*r;}}
    private void sendPosition(){Intent p=new Intent(ACTION_POSITION);p.setPackage(getPackageName());p.putExtra("lat",lat);p.putExtra("lon",lon);p.putExtra("steps",steps);p.putExtra("cadence",cadence);p.putExtra("stride",strideCm);p.putExtra("speed",speed);p.putExtra("paused",paused);sendBroadcast(p);}
    private void stopSimulation(){running=false;paused=false;joyX=joyY=0;handler.removeCallbacks(ticker);try{lm.setTestProviderEnabled(LocationManager.GPS_PROVIDER,false);lm.removeTestProvider(LocationManager.GPS_PROVIDER);}catch(Exception ignored){}}
    @Override public void onDestroy(){stopSimulation();if(joystickReceiver!=null)try{unregisterReceiver(joystickReceiver);}catch(Exception ignored){}super.onDestroy();}
    @Override public android.os.IBinder onBind(Intent i){return null;}
}
