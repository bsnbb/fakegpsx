package com.fakewalkerx.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;

/** Draggable floating joystick with a spring-return thumb and a dedicated drag handle. */
public class FloatingJoystickService extends Service {
    private static final int NOTIFICATION_ID = 17;
    private WindowManager windowManager;
    private JoystickOverlay overlay;
    private WindowManager.LayoutParams layoutParams;
    private SharedPreferences prefs;
    private int alpha = 235;
    private float scale = 1f;
    private boolean overlayFailed = false;

    @Override public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences("settings", MODE_PRIVATE);
        alpha = Math.max(40, Math.min(255, Math.round(prefs.getInt("overlay_alpha", 92) * 2.55f)));
        scale = Math.max(.55f, Math.min(1.8f, prefs.getInt("overlay_size", 88) / 88f));
        startForeground(NOTIFICATION_ID, notification());
        if (!Settings.canDrawOverlays(this)) { overlayFailed = true; stopSelf(); return; }
        showJoystick();
    }

    private Notification notification() {
        String channelId = "fwx_overlay";
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(channelId, "FakeWalker X 悬浮控制", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
            return new Notification.Builder(this, channelId)
                    .setContentTitle("FakeWalker X 正在运行")
                    .setContentText("拖动顶部可移动面板，按住摇杆控制方向")
                    .setSmallIcon(android.R.drawable.ic_media_play).setOngoing(true).build();
        }
        return new Notification.Builder(this).setContentTitle("FakeWalker X 正在运行")
                .setContentText("悬浮摇杆已开启").setSmallIcon(android.R.drawable.ic_media_play).setOngoing(true).build();
    }

    private int dp(float value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    private void showJoystick() {
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        int width = dp(196 * scale), height = dp(242 * scale);
        layoutParams = new WindowManager.LayoutParams(width, height, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        layoutParams.gravity = Gravity.TOP | Gravity.START;
        layoutParams.x = prefs.getInt("overlay_x", dp(18));
        layoutParams.y = prefs.getInt("overlay_y", dp(180));
        clampWindowPosition();
        overlay = new JoystickOverlay(this);
        try {
            windowManager.addView(overlay, layoutParams);
        } catch (RuntimeException e) {
            android.util.Log.e("FakeWalkerX", "Unable to show floating joystick", e);
            overlayFailed = true;
            stopSelf();
        }
    }

    private void sendVector(float x, float y) {
        Intent move = new Intent(MainActivity.ACTION_JOYSTICK);
        move.setPackage(getPackageName());
        move.putExtra("x", x);
        move.putExtra("y", y);
        sendBroadcast(move);
    }

    private void clampWindowPosition() {
        if (layoutParams == null) return;
        android.util.DisplayMetrics metrics = new android.util.DisplayMetrics();
        if (Build.VERSION.SDK_INT >= 30) {
            android.graphics.Rect bounds = windowManager.getCurrentWindowMetrics().getBounds();
            layoutParams.x = Math.max(0, Math.min(layoutParams.x, Math.max(0, bounds.width() - layoutParams.width)));
            layoutParams.y = Math.max(0, Math.min(layoutParams.y, Math.max(0, bounds.height() - layoutParams.height)));
        } else {
            windowManager.getDefaultDisplay().getMetrics(metrics);
            layoutParams.x = Math.max(0, Math.min(layoutParams.x, Math.max(0, metrics.widthPixels - layoutParams.width)));
            layoutParams.y = Math.max(0, Math.min(layoutParams.y, Math.max(0, metrics.heightPixels - layoutParams.height)));
        }
    }

    private void savePosition() {
        if (prefs.getBoolean("remember_pos", true)) {
            prefs.edit().putInt("overlay_x", layoutParams.x).putInt("overlay_y", layoutParams.y).apply();
        }
    }

    private final class JoystickOverlay extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rect = new RectF();
        private final float density = getResources().getDisplayMetrics().density;
        private final float panelRadius = 22 * density;
        private float vectorX, vectorY, downRawX, downRawY, startWindowX, startWindowY;
        private float centerX, centerY, ringRadius, headerHeight;
        private boolean movingWindow, controlling;
        private String direction = "READY · TOUCH TO MOVE";

        JoystickOverlay(Context context) { super(context); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }

        private void color(int c) { paint.setColor(c); paint.setStyle(Paint.Style.FILL); paint.setShader(null); paint.clearShadowLayer(); }
        private void label(Canvas canvas, String value, float x, float y, float size, int c, boolean bold) {
            color(c); paint.setTextSize(size * density); paint.setTypeface(bold ? Typeface.create("sans-serif", Typeface.BOLD) : Typeface.create("sans-serif", Typeface.NORMAL));
            canvas.drawText(value, x, y, paint);
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth(), h = getHeight();
            headerHeight = 43 * density;
            centerX = w / 2f;
            centerY = h * .61f;
            ringRadius = Math.min(w * .315f, h * .255f);

            rect.set(2 * density, 2 * density, w - 2 * density, h - 2 * density);
            color(Color.argb(Math.min(250, alpha), 10, 20, 36));
            paint.setShadowLayer(12 * density, 0, 5 * density, 0x66000000);
            canvas.drawRoundRect(rect, panelRadius, panelRadius, paint);
            paint.clearShadowLayer();
            color(Color.argb(Math.min(255, alpha + 15), 20, 36, 57));
            rect.set(3 * density, 3 * density, w - 3 * density, headerHeight);
            canvas.drawRoundRect(rect, panelRadius - 2 * density, panelRadius - 2 * density, paint);
            color(0xff31d6b3); canvas.drawRoundRect(12 * density, 13 * density, 15 * density, 31 * density, 2 * density, 2 * density, paint);
            label(canvas, "FAKEWALKER", 22 * density, 20 * density, 10, Color.WHITE, true);
            label(canvas, "FLOAT CONTROL", 22 * density, 33 * density, 7, 0xff8fa4bd, false);

            float closeX = w - 22 * density, closeY = 22 * density;
            color(0xffe45465); canvas.drawCircle(closeX, closeY, 11 * density, paint);
            color(Color.WHITE); paint.setStrokeWidth(1.7f * density); paint.setStrokeCap(Paint.Cap.ROUND);
            canvas.drawLine(closeX - 3.5f * density, closeY - 3.5f * density, closeX + 3.5f * density, closeY + 3.5f * density, paint);
            canvas.drawLine(closeX + 3.5f * density, closeY - 3.5f * density, closeX - 3.5f * density, closeY + 3.5f * density, paint);

            // Subtle cardinal labels make the control legible without crowding the touch area.
            label(canvas, "N", centerX - 3 * density, centerY - ringRadius - 7 * density, 8, 0xff9bb0c7, true);
            label(canvas, "S", centerX - 3 * density, centerY + ringRadius + 15 * density, 8, 0xff9bb0c7, true);
            label(canvas, "W", centerX - ringRadius - 15 * density, centerY + 3 * density, 8, 0xff9bb0c7, true);
            label(canvas, "E", centerX + ringRadius + 7 * density, centerY + 3 * density, 8, 0xff9bb0c7, true);

            color(0x2229d8b0); canvas.drawCircle(centerX, centerY, ringRadius + 8 * density, paint);
            color(0xff253b52); paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(1.4f * density); canvas.drawCircle(centerX, centerY, ringRadius, paint); paint.setStyle(Paint.Style.FILL);
            color(0xff1b2b40); canvas.drawCircle(centerX, centerY, ringRadius * .67f, paint);
            color(0x5531d6b3); paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(1 * density); canvas.drawCircle(centerX, centerY, ringRadius * .34f, paint); paint.setStyle(Paint.Style.FILL);
            float knobX = centerX + vectorX * ringRadius * .66f, knobY = centerY + vectorY * ringRadius * .66f;
            color(0x6631d6b3); canvas.drawCircle(knobX, knobY + 2 * density, ringRadius * .40f, paint);
            color(0xff31d6b3); canvas.drawCircle(knobX, knobY, ringRadius * .36f, paint);
            color(0xffe8fff9); canvas.drawCircle(knobX, knobY, ringRadius * .12f, paint);

            label(canvas, direction, 13 * density, h - 13 * density, 8, controlling ? 0xff31d6b3 : 0xff91a5bb, true);
            label(canvas, controlling ? String.format(java.util.Locale.US, "%d%%", Math.round(Math.hypot(vectorX, vectorY) * 100)) : "SPRING RETURN", w - 13 * density - paint.measureText(controlling ? String.format(java.util.Locale.US, "%d%%", Math.round(Math.hypot(vectorX, vectorY) * 100)) : "SPRING RETURN"), h - 13 * density, 7, 0xff91a5bb, false);
        }

        private void updateVector(float x, float y) {
            float radius = Math.max(1, ringRadius);
            vectorX = x / radius; vectorY = y / radius;
            float length = (float) Math.hypot(vectorX, vectorY);
            if (length > 1) { vectorX /= length; vectorY /= length; length = 1; }
            if (length < .07f) { vectorX = 0; vectorY = 0; length = 0; }
            if (length == 0) direction = "READY · TOUCH TO MOVE";
            else if (Math.abs(vectorX) > Math.abs(vectorY) * 1.8f) direction = vectorX > 0 ? "MOVING EAST  →" : "←  MOVING WEST";
            else if (Math.abs(vectorY) > Math.abs(vectorX) * 1.8f) direction = vectorY > 0 ? "MOVING SOUTH  ↓" : "↑  MOVING NORTH";
            else direction = vectorY > 0 ? (vectorX > 0 ? "SOUTH-EAST  ↘" : "SOUTH-WEST  ↙") : (vectorX > 0 ? "NORTH-EAST  ↗" : "NORTH-WEST  ↖");
            sendVector(vectorX, vectorY);
            invalidate();
        }

        @Override public boolean onTouchEvent(MotionEvent event) {
            float x = event.getX(), y = event.getY();
            float closeX = getWidth() - 22 * density, closeY = 22 * density;
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downRawX = event.getRawX(); downRawY = event.getRawY();
                    startWindowX = layoutParams.x; startWindowY = layoutParams.y;
                    if (Math.hypot(x - closeX, y - closeY) <= 17 * density) {
                        stopSelf(); return true;
                    }
                    if (y <= headerHeight) { movingWindow = true; return true; }
                    float distance = (float) Math.hypot(x - centerX, y - centerY);
                    if (distance <= ringRadius + 18 * density) {
                        controlling = true; updateVector(x - centerX, y - centerY); return true;
                    }
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (movingWindow) {
                        layoutParams.x = Math.round(startWindowX + event.getRawX() - downRawX);
                        layoutParams.y = Math.round(startWindowY + event.getRawY() - downRawY);
                        clampWindowPosition();
                        try { windowManager.updateViewLayout(this, layoutParams); } catch (Exception ignored) { }
                    } else if (controlling) updateVector(x - centerX, y - centerY);
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (controlling) { controlling = false; vectorX = vectorY = 0; direction = "READY · TOUCH TO MOVE"; sendVector(0, 0); invalidate(); }
                    if (movingWindow) savePosition();
                    movingWindow = false; controlling = false;
                    return true;
                default: return true;
            }
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        return overlayFailed ? START_NOT_STICKY : START_STICKY;
    }

    @Override public void onDestroy() {
        sendVector(0, 0);
        if (windowManager != null && overlay != null) {
            try { windowManager.removeView(overlay); } catch (Exception ignored) { }
        }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
