# 保留堆栈行号与文件名，便于定位 release 崩溃/异常
-keepattributes SourceFile,LineNumberTable

# Ktor
# Keep ServiceLoader implementations (OkHttp engine discovery + kotlinx-json provider).
-keep class io.ktor.client.engine.okhttp.*EngineContainer { *; }
-keep class io.ktor.serialization.kotlinx.json.*ExtensionProvider { *; }
-keepclassmembers class io.ktor.** { volatile <fields>; }
-dontwarn io.ktor.**

# kotlinx.serialization
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class kotlinx.serialization.json.** { *** Companion; }
-keepclasseswithmembers class kotlinx.serialization.json.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-keep,includedescriptorclasses class com.github.ilife798.**$$serializer { *; }
-keepclassmembers class com.github.ilife798.** {
    *** Companion;
}
-keepclasseswithmembers class com.github.ilife798.** {
    kotlinx.serialization.KSerializer serializer(...);
}

# OkHttp
-dontwarn okhttp3.internal.platform.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**
