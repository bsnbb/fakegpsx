package com.fakewalkerx.app;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationManager;
import android.os.*;
import android.provider.Settings;
import android.view.Gravity;
import android.webkit.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    public static final String ACTION_JOYSTICK="com.fakewalkerx.app.JOYSTICK";
    // AMap Web JS API key supplied by the user. If the AMap console requires a security code,
    // set it in WEB_SECURITY_CODE below.
    private static final String WEB_KEY="e73e8345d5dd03d7af5c4ea9f4be4fcd";
    private static final String WEB_SECURITY_CODE="9d6910ec52ef610d4ba2628014d23da4";
    private WebView mapView; private TextView status, speedText, cadenceText, mapTip, stepsText;
    private SeekBar speedBar, cadenceBar, strideBar; private LocationManager lm;
    private LatLng point; private boolean running=false, simulationPaused=false, routeMode=false, mapReady=false; private double speed=1.3, joyX=0, joyY=0; private int cadence=110, stride=65; private final ArrayList<LatLng> routePoints=new ArrayList<>(); private int routeIndex=0;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final BroadcastReceiver joystickReceiver=new BroadcastReceiver(){@Override public void onReceive(Context c,Intent i){if(ACTION_JOYSTICK.equals(i.getAction())){joyX=i.getFloatExtra("x",0);joyY=i.getFloatExtra("y",0);}else if(SimulationService.ACTION_POSITION.equals(i.getAction())){point=new LatLng(i.getDoubleExtra("lat",39.9087),i.getDoubleExtra("lon",116.3975));long steps=i.getLongExtra("steps",0);if(stepsText!=null)stepsText.setText("模拟步数  "+steps+" 步");if(speedText!=null)speedText.setText(String.format(Locale.US,"速度 %.1f km/h",i.getDoubleExtra("speed",speed)*3.6));updateMapPoint(point);}else if(SimulationService.ACTION_FINISHED.equals(i.getAction())){running=false;simulationPaused=false;Toast.makeText(MainActivity.this,"路线模拟完成",Toast.LENGTH_SHORT).show();}else if(SimulationService.ACTION_ERROR.equals(i.getAction())){running=false;simulationPaused=false;String message=i.getStringExtra("message");Toast.makeText(MainActivity.this,message==null?"模拟定位启动失败，请检查开发者选项中的模拟位置应用":message,Toast.LENGTH_LONG).show();}}};

    public class MapBridge {
        @JavascriptInterface public void ready(double lat,double lon){runOnUiThread(()->{mapReady=true;if(point==null)point=new LatLng(lat,lon);});}
        @JavascriptInterface public void clicked(double lat,double lon){runOnUiThread(()->handleMapClick(new LatLng(lat,lon)));}
    }
    @Override public void onCreate(Bundle b){super.onCreate(b);lm=(LocationManager)getSystemService(LOCATION_SERVICE);build(b);IntentFilter filters=new IntentFilter();filters.addAction(ACTION_JOYSTICK);filters.addAction(SimulationService.ACTION_POSITION);filters.addAction(SimulationService.ACTION_FINISHED);filters.addAction(SimulationService.ACTION_ERROR);if(Build.VERSION.SDK_INT>=33)registerReceiver(joystickReceiver,filters,Context.RECEIVER_NOT_EXPORTED);else registerReceiver(joystickReceiver,filters);if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},10);}
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
    private void build(Bundle state){
        LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(Color.rgb(9,16,29));
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);top.setPadding(dp(18),dp(12),dp(12),dp(12));LinearLayout brand=new LinearLayout(this);brand.setOrientation(1);TextView title=text("FakeWalker X",22,Color.WHITE);title.setTypeface(null,1);brand.addView(title);brand.addView(text("LOCATION CONTROL  ·  2.1 WEB MAP",10,0xff7e91aa));top.addView(brand,new LinearLayout.LayoutParams(0,dp(54),1));Button settings=btn("⚙ 设置");top.addView(settings);root.addView(top);
        LinearLayout mapTools=new LinearLayout(this);mapTools.setGravity(Gravity.CENTER_VERTICAL);mapTools.setPadding(dp(10),dp(4),dp(10),dp(4));EditText searchBox=new EditText(this);searchBox.setSingleLine(true);searchBox.setTextColor(Color.WHITE);searchBox.setHintTextColor(0xff91a1b7);searchBox.setHint("搜索地点 / 地址");searchBox.setTextSize(14);mapTools.addView(searchBox,new LinearLayout.LayoutParams(0,dp(48),1));Button searchBtn=btn("搜索");Button currentBtn=btn("回到当前位置");mapTools.addView(searchBtn);mapTools.addView(currentBtn);root.addView(mapTools);searchBtn.setOnClickListener(v->{String q=searchBox.getText().toString().trim();if(q.isEmpty()){Toast.makeText(this,"请输入地点名称或地址",Toast.LENGTH_SHORT).show();return;}mapView.evaluateJavascript("searchPlace("+org.json.JSONObject.quote(q)+")",null);});currentBtn.setOnClickListener(v->centerOnCurrentLocation());
        FrameLayout mapFrame=new FrameLayout(this);mapView=new WebView(this);mapView.setBackgroundColor(0xff101a2b);mapView.getSettings().setJavaScriptEnabled(true);mapView.getSettings().setDomStorageEnabled(true);mapView.setWebChromeClient(new WebChromeClient());mapView.addJavascriptInterface(new MapBridge(),"AndroidMap");mapFrame.addView(mapView);mapTip=text("正在加载高德 Web 地图…",12,Color.WHITE);mapTip.setPadding(dp(12),dp(8),dp(12),dp(8));mapTip.setBackgroundColor(0xcc101a2b);FrameLayout.LayoutParams tp=new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.START);tp.setMargins(dp(12),dp(12),0,0);mapFrame.addView(mapTip,tp);root.addView(mapFrame,new LinearLayout.LayoutParams(-1,0,1));mapView.loadDataWithBaseURL("https://webapi.amap.com/",mapHtml(),"text/html","UTF-8",null);
        android.content.SharedPreferences prefs=getSharedPreferences("settings",MODE_PRIVATE);
        cadence=Math.max(1,Math.min(240,prefs.getInt("cadence",110)));
        stride=Math.max(20,Math.min(120,prefs.getInt("stride",65)));
        speed=Math.max(.3,cadence*stride/100.0/60.0);
        LinearLayout panel=new LinearLayout(this);panel.setOrientation(1);panel.setPadding(dp(18),dp(14),dp(18),dp(14));panel.setBackgroundColor(0xff111d30);LinearLayout stats=new LinearLayout(this);stats.setGravity(Gravity.CENTER_VERTICAL);TextView stateLabel=text("● 已就绪",13,0xff31d6b3);stats.addView(stateLabel,new LinearLayout.LayoutParams(0,-2,1));speedText=text("速度 4.7 km/h",13,Color.WHITE);stats.addView(speedText);panel.addView(stats);
        speedBar=new SeekBar(this);speedBar.setMax(80);speedBar.setProgress(Math.max(3,Math.min(80,(int)Math.round(speed*10))));panel.addView(caption("移动速度"));panel.addView(speedBar);speedBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean u){speed=Math.max(.3,p/10.0);speedText.setText(String.format(Locale.US,"速度 %.1f km/h",speed*3.6));}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}});
        cadenceText=text("步频 "+cadence+" 步/分  ·  步幅 "+stride+" cm",13,Color.WHITE);panel.addView(cadenceText);stepsText=text("模拟步数  0 步",13,0xff31d6b3);panel.addView(stepsText);cadenceBar=new SeekBar(this);cadenceBar.setMax(240);cadenceBar.setProgress(110);panel.addView(cadenceBar);strideBar=new SeekBar(this);strideBar.setMax(120);strideBar.setProgress(65);panel.addView(caption("步幅（厘米）"));panel.addView(strideBar);
        android.widget.SeekBar.OnSeekBarChangeListener cadenceListener=new android.widget.SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean u){cadence=Math.max(1,cadenceBar.getProgress());stride=Math.max(20,strideBar.getProgress());speed=Math.max(.3,cadence*stride/100.0/60.0);speedBar.setProgress((int)(speed*10));cadenceText.setText("步频 "+cadence+" 步/分  ·  步幅 "+stride+" cm");speedText.setText(String.format(Locale.US,"速度 %.1f km/h",speed*3.6));}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}};cadenceBar.setOnSeekBarChangeListener(cadenceListener);strideBar.setOnSeekBarChangeListener(cadenceListener);
        LinearLayout actions=new LinearLayout(this);actions.setPadding(0,dp(8),0,0);Button start=btn("▶ 开始"),pause=btn("Ⅱ 暂停"),stop=btn("■ 停止");actions.addView(start,new LinearLayout.LayoutParams(0,dp(48),1));actions.addView(pause,new LinearLayout.LayoutParams(0,dp(48),1));actions.addView(stop,new LinearLayout.LayoutParams(0,dp(48),1));panel.addView(actions);LinearLayout extras=new LinearLayout(this);Button overlay=btn("开启悬浮摇杆"),route=btn("路线模式");extras.addView(overlay,new LinearLayout.LayoutParams(0,dp(44),1));extras.addView(route,new LinearLayout.LayoutParams(0,dp(44),1));panel.addView(extras);panel.addView(text("步频仅用于估算移动速度与本应用模拟步数；免 Root 模式不会伪造系统计步器传感器。",10,0xff91a1b7));root.addView(panel);setContentView(root);
        settings.setOnClickListener(v->startActivity(new Intent(this,SettingsActivity.class)));
        start.setOnClickListener(v->startMock());pause.setOnClickListener(v->{if(!running){Toast.makeText(this,"请先点击开始",Toast.LENGTH_SHORT).show();return;}simulationPaused=!simulationPaused;Intent pi=new Intent(this,SimulationService.class);pi.setAction(SimulationService.ACTION_TOGGLE);startServiceCompat(pi);stateLabel.setText(simulationPaused?"Ⅱ 已暂停":"● 正在模拟");});stop.setOnClickListener(v->{running=false;simulationPaused=false;joyX=joyY=0;Intent si=new Intent(this,SimulationService.class);si.setAction(SimulationService.ACTION_STOP);startServiceCompat(si);stateLabel.setText("● 已停止");});
        overlay.setOnClickListener(v->{
            if(!Settings.canDrawOverlays(this)){
                getSharedPreferences("settings",MODE_PRIVATE).edit().putBoolean("start_overlay_after_permission",true).apply();
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,android.net.Uri.parse("package:"+getPackageName())));
                return;
            }
            startFloatingJoystick();
        });
        route.setOnClickListener(v->{if(!routeMode){routeMode=true;routePoints.clear();mapTip.setText("路线编辑中：点击地图添加至少 2 个路线点");Toast.makeText(this,"依次点击地图添加路线点",Toast.LENGTH_SHORT).show();route.setText("完成路线");}else{routeMode=false;route.setText("路线模式");if(routePoints.size()<2){routePoints.clear();mapTip.setText("路线点不足，已取消路线编辑");Toast.makeText(this,"至少添加两个路线点",Toast.LENGTH_SHORT).show();}else{point=routePoints.get(0);routeIndex=1;redrawRoute();mapTip.setText("路线已就绪：点开始后按路线行走");Toast.makeText(this,"路线已保存，点击开始模拟",Toast.LENGTH_SHORT).show();}}});
    }
    private String mapHtml(){String effectiveKey=WEB_KEY;String security=WEB_SECURITY_CODE.isEmpty()?"":"window._AMapSecurityConfig={securityJsCode:'"+WEB_SECURITY_CODE+"'};";return "<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no'><meta charset='utf-8'><style>html,body,#map{margin:0;width:100%;height:100%;overflow:hidden}</style><script>"+security+"</script><script src='https://webapi.amap.com/maps?v=2.0&key="+effectiveKey+"&plugin=AMap.PlaceSearch'></script></head><body><div id='map'></div><script>var map=new AMap.Map('map',{zoom:16,center:[116.3975,39.9087],viewMode:'2D'});var marker=null,routeLine=null,routeMarkers=[];map.on('complete',function(){var c=map.getCenter();AndroidMap.ready(c.lat,c.lng)});map.on('click',function(e){AndroidMap.clicked(e.lnglat.lat,e.lnglat.lng)});function setPoint(lat,lon){if(marker)marker.setMap(null);marker=new AMap.Marker({position:[lon,lat],title:'模拟位置'});marker.setMap(map)}function setRoute(points,lat,lon){routeMarkers.forEach(function(m){m.setMap(null)});routeMarkers=[];if(routeLine)routeLine.setMap(null);if(points&&points.length){points.forEach(function(p,i){var m=new AMap.Marker({position:[p.lon,p.lat],title:'路线点 '+(i+1)});m.setMap(map);routeMarkers.push(m)});if(points.length>1){routeLine=new AMap.Polyline({path:points.map(function(p){return [p.lon,p.lat]}),strokeColor:'#31d6b3',strokeWeight:4});routeLine.setMap(map)}}if(lat!==null&&lon!==null)setPoint(lat,lon)}function centerAt(lat,lon){map.setCenter([lon,lat]);setPoint(lat,lon)}function searchPlace(q){var ps=new AMap.PlaceSearch({pageSize:8});ps.search(q,function(status,result){if(status==='complete'&&result.poiList&&result.poiList.pois.length){var p=result.poiList.pois[0];map.setCenter([p.location.lng,p.location.lat]);map.setZoom(16);setPoint(p.location.lat,p.location.lng);AndroidMap.clicked(p.location.lat,p.location.lng)}else{alert('没有找到该地点，请换个关键词');}})}</script></body></html>";}
    private void centerOnCurrentLocation(){try{if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},10);Toast.makeText(this,"请先授予定位权限，再点击一次",Toast.LENGTH_SHORT).show();return;}Location best=null;for(String provider:lm.getProviders(true)){Location l=lm.getLastKnownLocation(provider);if(l!=null&&(best==null||l.getTime()>best.getTime()))best=l;}if(best==null){Toast.makeText(this,"暂时没有设备定位结果，请开启系统定位后重试",Toast.LENGTH_LONG).show();return;}point=new LatLng(best.getLatitude(),best.getLongitude());mapView.evaluateJavascript("centerAt("+point.latitude+","+point.longitude+")",null);mapTip.setText(String.format(Locale.US,"当前位置  %.5f, %.5f",point.latitude,point.longitude));}catch(SecurityException e){Toast.makeText(this,"没有定位权限",Toast.LENGTH_SHORT).show();}}
    private void handleMapClick(LatLng p){if(routeMode){routePoints.add(p);redrawRoute();mapTip.setText("路线点 "+routePoints.size()+" · 继续点击地图添加途经点");}else{point=p;redrawRoute();mapTip.setText(String.format(Locale.US,"已选位置  %.5f, %.5f",p.latitude,p.longitude));}}
    private TextView caption(String s){TextView t=text(s,11,0xff91a1b7);t.setPadding(0,dp(6),0,0);return t;}
    private Button btn(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextSize(12);return b;}
    private void startMock(){try{if(point==null)point=new LatLng(39.9087,116.3975);if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){Toast.makeText(this,"请先授予定位权限",Toast.LENGTH_LONG).show();return;}Intent i=new Intent(this,SimulationService.class);i.setAction(SimulationService.ACTION_START);i.putExtra("lat",point.latitude);i.putExtra("lon",point.longitude);i.putExtra("speed",speed);i.putExtra("cadence",cadence);i.putExtra("stride",stride);if(routePoints.size()>1){double[] lats=new double[routePoints.size()],lons=new double[routePoints.size()];for(int n=0;n<routePoints.size();n++){lats[n]=routePoints.get(n).latitude;lons[n]=routePoints.get(n).longitude;}i.putExtra("route_lats",lats);i.putExtra("route_lons",lons);}startForegroundServiceCompat(i);running=true;simulationPaused=false;stepsText.setText("模拟步数  0 步");Toast.makeText(this,"已请求后台模拟。请在开发者选项中选择本应用为模拟位置应用",Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,"启动失败："+e.getMessage(),Toast.LENGTH_LONG).show();}}
    private void startForegroundServiceCompat(Intent i){if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);}private void startServiceCompat(Intent i){if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);}
    private void updateMapPoint(LatLng p){runOnUiThread(()->{if(mapView!=null)mapView.evaluateJavascript("setPoint("+p.latitude+","+p.longitude+")",null);});}
    private void redrawRoute(){if(mapView==null)return;StringBuilder a=new StringBuilder("[");for(int n=0;n<routePoints.size();n++){if(n>0)a.append(',');LatLng p=routePoints.get(n);a.append("{lat:").append(p.latitude).append(",lon:").append(p.longitude).append('}');}a.append(']');String lat=point==null?"null":String.valueOf(point.latitude),lon=point==null?"null":String.valueOf(point.longitude);mapView.evaluateJavascript("setRoute("+a+","+lat+","+lon+")",null);}
    private LatLng offset(LatLng p,double north,double east){double lat=p.latitude+north/111320.0;double lon=p.longitude+east/Math.max(1000,111320*Math.cos(Math.toRadians(p.latitude)));return new LatLng(lat,lon);}
    @Override protected void onResume(){
        super.onResume();
        android.content.SharedPreferences prefs=getSharedPreferences("settings",MODE_PRIVATE);
        if(prefs.getBoolean("start_overlay_after_permission",false)){
            prefs.edit().putBoolean("start_overlay_after_permission",false).apply();
            if(Settings.canDrawOverlays(this)) startFloatingJoystick();
        }
    }
    private void startFloatingJoystick(){
        Intent i=new Intent(this,FloatingJoystickService.class);
        if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i);
        Toast.makeText(this,"悬浮摇杆已开启；请先点击“开始”启动模拟，再将应用切到后台操控。",Toast.LENGTH_LONG).show();
    }
    @Override protected void onPause(){super.onPause();}@Override protected void onDestroy(){try{if(mapView!=null){mapView.removeJavascriptInterface("AndroidMap");mapView.destroy();}}catch(Exception ignored){}try{unregisterReceiver(joystickReceiver);}catch(Exception ignored){}super.onDestroy();}
    private static class LatLng{final double latitude,longitude;LatLng(double lat,double lon){latitude=lat;longitude=lon;}}
}
