package com.fakewalkerx;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.amap.api.maps.AMap;
import com.amap.api.maps.CameraUpdateFactory;
import com.amap.api.maps.MapView;
import com.amap.api.maps.model.LatLng;
import com.amap.api.maps.model.Marker;
import com.amap.api.maps.model.MarkerOptions;
import com.amap.api.maps.model.Polyline;
import com.amap.api.maps.model.PolylineOptions;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_LOCATION = 1001;
    private MapView mapView;
    private AMap map;
    private TextView status;
    private TextView speedLabel;
    private TextView cadenceLabel;
    private SeekBar speedBar;
    private SeekBar cadenceBar;
    private Button startButton;
    private Button pauseButton;
    private Button stopButton;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final List<LatLng> route = new ArrayList<>();
    private Polyline routeLine;
    private Marker currentMarker;
    private LocationManager locationManager;
    private boolean simulating = false;
    private boolean paused = false;
    private long lastTick = 0L;
    private double distanceAlong = 0.0;
    private double speedMps = 1.4;
    private int cadence = 110;
    private double joystickX = 0.0;
    private double joystickY = 0.0;
    private LatLng currentPoint;

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            if (!simulating || paused) return;
            long now = System.currentTimeMillis();
            double dt = lastTick == 0 ? 0.5 : Math.min(1.0, (now - lastTick) / 1000.0);
            lastTick = now;

            if (route.size() >= 2 && Math.abs(joystickX) < 0.05 && Math.abs(joystickY) < 0.05) {
                advanceRoute(speedMps * dt);
            } else {
                // 摇杆模式：以屏幕方向作为局部方向，按步频/步幅估算速度。
                if (currentPoint == null) currentPoint = map.getCameraPosition().target;
                double meters = speedMps * dt;
                double north = -joystickY * meters;
                double east = joystickX * meters;
                currentPoint = offsetMeters(currentPoint, north, east);
                publishPoint(currentPoint, speedMps, bearingFromVector(north, east));
            }
            handler.postDelayed(this, 500);
        }
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        buildUi(savedInstanceState);
        if (Build.VERSION.SDK_INT >= 23 &&
                checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
        }
    }

    private void buildUi(Bundle state) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(10, 15, 27));

        TextView title = new TextView(this);
        title.setText("FAKEWALKER X  •  LOCATION LAB");
        title.setTextColor(Color.WHITE);
        title.setTextSize(18);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setPadding(18, 12, 12, 12);
        root.addView(title, new LinearLayout.LayoutParams(-1, 52));

        mapView = new MapView(this);
        mapView.onCreate(state);
        root.addView(mapView, new LinearLayout.LayoutParams(-1, 0, 1f));
        map = mapView.getMap();
        map.getUiSettings().setZoomControlsEnabled(true);
        map.getUiSettings().setCompassEnabled(true);
        map.moveCamera(CameraUpdateFactory.zoomTo(16f));
        map.setOnMapClickListener(point -> {
            if (route.size() >= 2) {
                route.clear();
                if (routeLine != null) { routeLine.remove(); routeLine = null; }
            }
            route.add(point);
            if (routeLine != null) routeLine.remove();
            if (route.size() == 1) {
                map.addMarker(new MarkerOptions().position(point).title("起点"));
                currentPoint = point;
                map.moveCamera(CameraUpdateFactory.changeLatLng(point));
                setStatus("已设置起点：再点击地图设置终点");
            } else {
                routeLine = map.addPolyline(new PolylineOptions().add(route.get(0), route.get(1))
                        .width(10f).color(Color.rgb(0, 210, 255)));
                map.addMarker(new MarkerOptions().position(point).title("终点"));
                setStatus("路线已设置，可开始模拟");
            }
        });

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(12, 8, 12, 10);
        panel.setBackgroundColor(Color.rgb(18, 27, 43));

        status = new TextView(this);
        status.setTextColor(Color.rgb(125, 230, 255));
        status.setTextSize(13);
        status.setText("点地图选择起点，再点一次选择终点。先在系统开发者选项中选择本应用为模拟位置信息应用。");
        panel.addView(status, new LinearLayout.LayoutParams(-1, -2));

        speedLabel = label("速度：5.0 km/h");
        panel.addView(speedLabel);
        speedBar = new SeekBar(this);
        speedBar.setMax(180);
        speedBar.setProgress(50);
        panel.addView(speedBar);
        speedBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean user) {
                speedMps = Math.max(0.3, p / 10.0);
                speedLabel.setText(String.format(Locale.getDefault(), "速度：%.1f km/h", speedMps * 3.6));
            }
            public void onStartTrackingTouch(SeekBar b) {}
            public void onStopTrackingTouch(SeekBar b) {}
        });

        cadenceLabel = label("步频：110 步/分钟");
        panel.addView(cadenceLabel);
        cadenceBar = new SeekBar(this);
        cadenceBar.setMax(180);
        cadenceBar.setProgress(110);
        panel.addView(cadenceBar);
        cadenceBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean user) {
                cadence = Math.max(1, p);
                cadenceLabel.setText("步频：" + cadence + " 步/分钟");
                // 步频控制速度估算：假定步幅 0.65 米，可再由速度滑杆微调。
                speedMps = Math.max(0.3, Math.min(5.0, cadence * 0.65 / 60.0));
                speedLabel.setText(String.format(Locale.getDefault(), "速度：%.1f km/h", speedMps * 3.6));
            }
            public void onStartTrackingTouch(SeekBar b) {}
            public void onStopTrackingTouch(SeekBar b) {}
        });

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        startButton = button("开始");
        pauseButton = button("暂停");
        stopButton = button("停止");
        buttons.addView(startButton, new LinearLayout.LayoutParams(0, 48, 1));
        buttons.addView(pauseButton, new LinearLayout.LayoutParams(0, 48, 1));
        buttons.addView(stopButton, new LinearLayout.LayoutParams(0, 48, 1));
        panel.addView(buttons);
        startButton.setOnClickListener(v -> startSimulation());
        pauseButton.setOnClickListener(v -> {
            if (!simulating) return;
            paused = !paused;
            pauseButton.setText(paused ? "继续" : "暂停");
            if (paused) handler.removeCallbacks(ticker);
            else { lastTick = 0; handler.post(ticker); }
        });
        stopButton.setOnClickListener(v -> stopSimulation());

        TextView joystickTitle = label("摇杆控制（按住并拖动）");
        panel.addView(joystickTitle);
        JoystickView joystick = new JoystickView(this);
        panel.addView(joystick, new LinearLayout.LayoutParams(-1, 90));
        root.addView(panel, new LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(root);
    }

    private TextView label(String text) {
        TextView v = new TextView(this);
        v.setText(text); v.setTextColor(Color.WHITE); v.setTextSize(13);
        v.setPadding(2, 5, 2, 2);
        return v;
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        return b;
    }

    private void startSimulation() {
        if (Build.VERSION.SDK_INT >= 23 &&
                checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "请先授予定位权限", Toast.LENGTH_LONG).show(); return;
        }
        if (route.size() < 2 && Math.abs(joystickX) < 0.05 && Math.abs(joystickY) < 0.05) {
            Toast.makeText(this, "请先在地图选择起点和终点，或使用摇杆移动", Toast.LENGTH_LONG).show();
            // Allow joystick mode to begin from current map center.
            currentPoint = map.getCameraPosition().target;
        }
        try {
            enableMockProvider();
            simulating = true; paused = false; lastTick = 0;
            startButton.setText("运行中");
            pauseButton.setText("暂停");
            handler.removeCallbacks(ticker);
            handler.post(ticker);
            setStatus("模拟已启动。系统可能会将模拟位置标记为 Mock；第三方应用兼容性不保证。");
        } catch (SecurityException e) {
            setStatus("授权失败：请到开发者选项 → 选择模拟位置信息应用 → FakeWalker X");
            Toast.makeText(this, "尚未授权本应用为模拟位置应用", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            setStatus("启动失败：" + e.getClass().getSimpleName() + "，请检查模拟位置授权");
        }
    }

    private void enableMockProvider() {
        try { locationManager.removeTestProvider(LocationManager.GPS_PROVIDER); } catch (Exception ignored) {}
        if (Build.VERSION.SDK_INT >= 31) {
            android.location.provider.ProviderProperties props =
                    new android.location.provider.ProviderProperties.Builder()
                            .setAccuracy(android.location.provider.ProviderProperties.ACCURACY_FINE)
                            .setPowerUsage(android.location.provider.ProviderProperties.POWER_USAGE_HIGH)
                            .build();
            locationManager.addTestProvider(LocationManager.GPS_PROVIDER, props);
        } else {
            locationManager.addTestProvider(LocationManager.GPS_PROVIDER, false, true, false,
                    false, true, true, true, android.location.Criteria.POWER_HIGH,
                    android.location.Criteria.ACCURACY_FINE);
        }
        locationManager.setTestProviderEnabled(LocationManager.GPS_PROVIDER, true);
    }

    private void advanceRoute(double meters) {
        if (route.size() < 2) return;
        LatLng a = route.get(0), b = route.get(1);
        double total = distanceMeters(a, b);
        if (total < 1) { currentPoint = b; publishPoint(b, speedMps, 0); return; }
        distanceAlong += meters;
        if (distanceAlong > total) distanceAlong = 0; // Repeat route for testing.
        double t = distanceAlong / total;
        currentPoint = new LatLng(a.latitude + (b.latitude - a.latitude) * t,
                a.longitude + (b.longitude - a.longitude) * t);
        float bearing = bearing(a, b);
        publishPoint(currentPoint, speedMps, bearing);
    }

    private void publishPoint(LatLng p, double speed, float bearing) {
        try {
            Location loc = new Location(LocationManager.GPS_PROVIDER);
            loc.setLatitude(p.latitude);
            loc.setLongitude(p.longitude);
            loc.setAccuracy(3.0f);
            loc.setAltitude(0);
            loc.setSpeed((float) speed);
            loc.setBearing(bearing);
            loc.setTime(System.currentTimeMillis());
            if (Build.VERSION.SDK_INT >= 17) loc.setElapsedRealtimeNanos(android.os.SystemClock.elapsedRealtimeNanos());
            locationManager.setTestProviderLocation(LocationManager.GPS_PROVIDER, loc);
            if (currentMarker == null) currentMarker = map.addMarker(new MarkerOptions().position(p).title("模拟位置"));
            else currentMarker.setPosition(p);
            setStatus(String.format(Locale.getDefault(),
                    "模拟运行中  •  %.6f, %.6f  •  %.1f km/h  •  %d 步/分",
                    p.latitude, p.longitude, speed * 3.6, cadence));
        } catch (SecurityException e) {
            setStatus("系统拒绝模拟位置：请确认开发者选项已选择本应用");
            stopSimulation();
        } catch (Exception e) {
            setStatus("位置更新失败：" + e.getClass().getSimpleName());
        }
    }

    private void stopSimulation() {
        simulating = false; paused = false; handler.removeCallbacks(ticker);
        startButton.setText("开始"); pauseButton.setText("暂停");
        try { locationManager.setTestProviderEnabled(LocationManager.GPS_PROVIDER, false); } catch (Exception ignored) {}
        setStatus("已停止。若系统仍保留模拟状态，请在开发者选项中切回原设置。");
    }

    private void setStatus(String text) { if (status != null) status.setText(text); }

    private static double distanceMeters(LatLng a, LatLng b) {
        float[] out = new float[1];
        Location.distanceBetween(a.latitude, a.longitude, b.latitude, b.longitude, out);
        return out[0];
    }

    private static float bearing(LatLng a, LatLng b) {
        float[] out = new float[2];
        Location.distanceBetween(a.latitude, a.longitude, b.latitude, b.longitude, out);
        return out[1];
    }

    private static float bearingFromVector(double north, double east) {
        return (float) ((Math.toDegrees(Math.atan2(east, north)) + 360.0) % 360.0);
    }

    private static LatLng offsetMeters(LatLng origin, double north, double east) {
        double lat = origin.latitude + north / 111320.0;
        double lonScale = 111320.0 * Math.cos(Math.toRadians(origin.latitude));
        double lon = origin.longitude + east / Math.max(1000.0, lonScale);
        return new LatLng(lat, lon);
    }

    private class JoystickView extends View {
        private android.graphics.Paint paint = new android.graphics.Paint(3);
        private float cx, cy, knobX, knobY, radius;
        public JoystickView(Activity context) { super(context); setBackgroundColor(Color.rgb(12, 19, 31)); }
        @Override protected void onDraw(android.graphics.Canvas c) {
            super.onDraw(c);
            cx = getWidth() / 2f; cy = getHeight() / 2f; radius = Math.min(getWidth() * 0.20f, getHeight() * 0.42f);
            paint.setColor(Color.rgb(45, 65, 88)); paint.setStyle(android.graphics.Paint.Style.FILL);
            c.drawCircle(cx, cy, radius, paint);
            paint.setColor(Color.rgb(0, 190, 230)); c.drawCircle(knobX == 0 ? cx : knobX, knobY == 0 ? cy : knobY, radius * 0.42f, paint);
            paint.setColor(Color.WHITE); paint.setTextSize(12);
            c.drawText("← 左右 →  /  ↑ 前进 ↓ 后退", 12, getHeight() - 8, paint);
        }
        @Override public boolean onTouchEvent(MotionEvent e) {
            float dx = e.getX() - cx, dy = e.getY() - cy;
            float max = Math.max(1, radius);
            float len = (float)Math.sqrt(dx*dx + dy*dy);
            if (len > max) { dx = dx * max / len; dy = dy * max / len; }
            if (e.getAction() == MotionEvent.ACTION_UP || e.getAction() == MotionEvent.ACTION_CANCEL) {
                joystickX = joystickY = 0; knobX = knobY = 0; invalidate(); return true;
            }
            joystickX = dx / max; joystickY = dy / max; knobX = cx + dx; knobY = cy + dy;
            invalidate(); return true;
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQ_LOCATION && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED)
            setStatus("定位权限已授予。请先在开发者选项中将 FakeWalker X 设为模拟位置信息应用。");
    }

    @Override protected void onResume() { super.onResume(); if (mapView != null) mapView.onResume(); }
    @Override protected void onPause() { if (mapView != null) mapView.onPause(); super.onPause(); }
    @Override protected void onSaveInstanceState(Bundle out) { super.onSaveInstanceState(out); if (mapView != null) mapView.onSaveInstanceState(out); }
    @Override protected void onDestroy() { stopSimulation(); if (mapView != null) mapView.onDestroy(); super.onDestroy(); }
}
